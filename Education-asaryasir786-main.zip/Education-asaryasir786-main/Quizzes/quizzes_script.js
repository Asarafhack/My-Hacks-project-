// quizzes_script.js

document.addEventListener('DOMContentLoaded', function() {
    // Add any quizzes related JavaScript code here
});
