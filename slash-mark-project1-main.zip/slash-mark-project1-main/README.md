# slash-mark-project1
Projects:

 Text Encryption Using Cryptographic Algorithms
          
  Description: You can build a simple web application to encrypt and decrypt textual information that the user keys in. Remember that strong encryption should produce different outputs even given the same input.



Keylogger Software

Description: Keylogger software is a good beginner-level cyber security project. A keylogger is software used to record every keystroke made by the user on their keyboard devices.

 Image Encryption

Description: The images must be encrypted in such a way that even with arbitrary access to them via the internet, the image must not be decryptable without a secure key. This project would help you delve into the basics of cybersecurity and develop your cryptography skills.
